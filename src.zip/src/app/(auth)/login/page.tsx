"use client";

import { useState } from "react";

export default function LoginPage() {
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => setLoading(false), 1500);
  };

  return (
    <main className="h-screen flex flex-col md:flex-row overflow-hidden">
      {/* Left Side: Branding */}
      <section className="hidden lg:flex relative w-[48%] h-full overflow-hidden">
        <div className="absolute inset-0">
  <img
    src="https://images.unsplash.com/photo-1502904550040-7534597429ae?q=80&w=1200"
    alt="Runners at sunrise"
    className="absolute inset-0 w-full h-full object-cover object-center z-0"
  />

    <div className="absolute inset-0 bg-black/35 z-10"></div>
    </div>

        <div className="absolute top-12 left-12 z-[999]">
          <img
    src="/logo.png.jpeg"
    alt="SRN Logo"
    className="h-12 w-auto"
/>
        </div>

        <div className="absolute bottom-12 left-12 z-20">
          <div className="glass-card rounded-3xl p-8 w-[380px]">
            <span className="text-white text-5xl leading-none">

            </span>
            <h1 className="text-white text-6xl font-black leading-[1.05] mt-2">
              The only run you regret is the one you didn&apos;t start.
            </h1>
            <p className="mt-8 text-lg text-white/90 leading-relaxed">
              Join 50,000+ runners chasing the dawn every morning.
            </p>
            <div className="mt-md flex items-center gap-sm">
              <span className="text-white font-label-bold text-xs">
                Active in your area
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Right Side: Login Form */}
      <section className="flex-1 h-full flex flex-col justify-center items-center p-md md:p-xl bg-surface-container-lowest overflow-y-auto">
        <div className="w-full max-w-[440px] space-y-lg">
          <div className="md:hidden flex justify-center mb-md">
            <img alt="SRN Logo" className="h-10 w-auto" src="/logo.png" />
          </div>

          <div className="space-y-1 text-center md:text-left">
            <h2 className="font-headline-lg text-2xl font-bold text-on-surface">
              Welcome Back, Runner
            </h2>
            <p className="font-body-md text-sm text-on-surface-variant">
              Access your dashboard and sync your latest stats.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-md">
            <button className="flex items-center justify-center gap-sm px-lg py-sm border-2 border-outline-variant rounded-xl font-label-bold text-sm text-on-surface hover:bg-surface-container transition-all active:scale-[0.98]">
              Google
            </button>
            <button className="flex items-center justify-center gap-sm px-lg py-sm border-2 border-outline-variant rounded-xl font-label-bold text-sm text-on-surface hover:bg-surface-container transition-all active:scale-[0.98]">
              Strava
            </button>
          </div>

          <div className="relative flex items-center py-1">
            <div className="flex-grow border-t border-outline-variant"></div>
            <span className="flex-shrink mx-md text-on-surface-variant font-label-bold text-xs">
              OR LOGIN WITH EMAIL
            </span>
            <div className="flex-grow border-t border-outline-variant"></div>
          </div>

          <form className="space-y-md" onSubmit={handleSubmit}>
            <div className="space-y-1">
              <label className="font-label-bold text-xs text-on-surface" htmlFor="email">
                EMAIL ADDRESS
              </label>
              <input
                className="w-full px-md py-sm bg-surface-container border-0 border-b-2 border-transparent rounded-lg input-focus-effect font-body-md transition-all"
                id="email"
                placeholder="runner@sunrise.com"
                type="email"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between items-center">
                <label className="font-label-bold text-xs text-on-surface" htmlFor="password">
                  PASSWORD
                </label>
                <a className="font-label-bold text-xs text-primary hover:underline" href="#">
                  Forgot password?
                </a>
              </div>
              <div className="relative">
                <input
                  className="w-full px-md py-sm bg-surface-container border-0 border-b-2 border-transparent rounded-lg input-focus-effect font-body-md transition-all"
                  id="password"
                  placeholder="••••••••"
                  type={showPassword ? "text" : "password"}
                />
                <button
                  type="button"
                  className="absolute right-md top-1/2 -translate-y-1/2 text-on-surface-variant"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  <span className="material-symbols-outlined text-lg">
                    {showPassword ? "visibility_off" : "visibility"}
                  </span>
                </button>
              </div>
            </div>

            <div className="flex items-center gap-sm">
              <input className="w-4 h-4 rounded border-outline-variant text-primary focus:ring-primary" id="remember" type="checkbox" />
              <label className="font-body-md text-xs text-on-surface-variant cursor-pointer" htmlFor="remember">
                Keep me logged in for 30 days
              </label>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full sunrise-gradient text-white font-label-bold text-sm py-sm rounded-full shadow-lg shadow-primary/20 hover:shadow-xl hover:shadow-primary/30 transition-all active:scale-[0.98] flex items-center justify-center gap-sm"
            >
              {loading ? (
                <>
                  <span className="material-symbols-outlined animate-spin text-lg">sync</span>
                  Authenticating...
                </>
              ) : (
                <>
                  Login to Network
                  <span className="material-symbols-outlined text-lg">arrow_forward</span>
                </>
              )}
            </button>
          </form>

          <p className="text-center font-body-md text-sm text-on-surface-variant">
            New to the network?{" "}
            <a className="text-primary font-label-bold hover:underline" href="#">
              Create a runner profile
            </a>
          </p>

          <p className="text-center text-xs text-on-surface-variant/60 font-body-md">
            © 2024 Sunrise Runners Network. All rights reserved.
          </p>
        </div>
      </section>
    </main>
  );
}